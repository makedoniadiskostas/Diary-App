</div>
    </main>
    <footer class="footer">
        <div class="container">
            <h3 class="footer__heading">PHP diary project</h3>
            <p class="footer__desc">This PHP diary project allows users to systematically document and reflect on their learning journey, enhancing retention and providing valuable insights into their personal growth and development.</p>
        </div>
    </footer>
</body>
</html>